
import streamlit as st
import pandas as pd
import numpy as np
import joblib

# Load model
model = joblib.load("ai_power_random_forest_model.pkl")

st.set_page_config(
    page_title="AI Power & Carbon Predictor",
    page_icon="⚡",
    layout="wide"
)

st.title("AI Training Power & Carbon Footprint Predictor")

st.write(
    "Predict the power consumption of an AI training workload "
    "from its workload configuration and hardware characteristics."
)

st.sidebar.header("Workload Configuration")

workload = st.sidebar.selectbox(
    "Workload",
    [
        "LLM",
        "Image Generation",
        "Feature Forecasting",
        "Image Classification",
        "Reinforcement Learning",
        "Image Captioning",
        "Text Generation"
    ]
)

hardware = st.sidebar.selectbox(
    "Hardware",
    ["RTX3060", "H100", "B200"]
)

num_gpus = st.sidebar.number_input(
    "Number of GPUs",
    min_value=1,
    max_value=8,
    value=1
)

batch_size = st.sidebar.number_input(
    "Batch Size",
    min_value=1,
    value=32
)

model_size = st.sidebar.number_input(
    "Model Size",
    min_value=0.0,
    value=0.0
)

image_size = st.sidebar.number_input(
    "Image Size",
    min_value=0.0,
    value=0.0
)

sequence_length = st.sidebar.number_input(
    "Sequence Length",
    min_value=0.0,
    value=0.0
)

layer_size = st.sidebar.number_input(
    "Layer Size",
    min_value=0.0,
    value=0.0
)

num_layers = st.sidebar.number_input(
    "Number of Layers",
    min_value=0.0,
    value=0.0
)

embedding_dim = st.sidebar.number_input(
    "Embedding Dimension",
    min_value=0.0,
    value=0.0
)

hidden_units = st.sidebar.number_input(
    "Hidden Units",
    min_value=0.0,
    value=0.0
)

num_filters = st.sidebar.number_input(
    "Number of Filters",
    min_value=0.0,
    value=0.0
)

optimizer = st.sidebar.selectbox(
    "Optimizer",
    ["Not_Applicable", "Adam", "SGD", "RMS"]
)

input_type = st.sidebar.selectbox(
    "Input Type",
    ["Not_Applicable", "Feature", "Sequence"]
)

parallelization = st.sidebar.selectbox(
    "Parallelization",
    ["Not_Applicable", "ZeRO-1", "ZeRO-2", "ZeRO-3"]
)

if st.button("Predict Power Consumption"):

    input_data = pd.DataFrame([{
        "workload": workload,
        "hardware": hardware,
        "num_gpus": num_gpus,
        "batch_size": batch_size,
        "model_size": model_size,
        "image_size": image_size,
        "sequence_length": sequence_length,
        "layer_size": layer_size,
        "num_layers": num_layers,
        "embedding_dim": embedding_dim,
        "hidden_units": hidden_units,
        "num_filters": num_filters,
        "optimizer": optimizer,
        "input_type": input_type,
        "parallelization": parallelization
    }])

    predicted_power = model.predict(input_data)[0]

    # One dataset window = 10 seconds
    energy_kwh = predicted_power * (10 / 3600) / 1000

    # Example grid carbon intensity
    carbon_intensity = 705.40

    estimated_emissions = (
        energy_kwh * carbon_intensity / 1000
    )

    st.subheader("Prediction Results")

    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric(
            "Predicted Power",
            f"{predicted_power:.2f} W"
        )

    with col2:
        st.metric(
            "Energy per 10-second Window",
            f"{energy_kwh:.5f} kWh"
        )

    with col3:
        st.metric(
            "Estimated CO₂e",
            f"{estimated_emissions:.5f} kg"
        )

    st.info(
        "The carbon estimate uses an electricity carbon intensity "
        "of 705.40 gCO₂e/kWh. This value represents the 2024 India "
        "scenario used in the research analysis."
    )
